//
//  SwipeCellKit.h
//  SwipeCellKit
//
//  Created by Jeremy Koch on 2/3/17.
//
//

#import <UIKit/UIKit.h>

//! Project version number for SwipeCellKit.
FOUNDATION_EXPORT double SwipeCellKitVersionNumber;

//! Project version string for SwipeCellKit.
FOUNDATION_EXPORT const unsigned char SwipeCellKitVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SwipeCellKit/PublicHeader.h>


