//
//  Setting.swift
//  ravenwallet
//
//  Created by Adrian Corscadden on 2017-04-01.
//  Copyright © 2018 Ravenwallet Team. All rights reserved.
//

import Foundation

struct AddressBook {
    var name: String
    var address: String
}
