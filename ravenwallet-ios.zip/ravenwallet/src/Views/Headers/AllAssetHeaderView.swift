//
//  AccountHeaderView.swift
//  ravenwallet
//
//  Created by Adrian Corscadden on 2016-11-16.
//  Copyright © 2018 Ravenwallet Team. All rights reserved.
//

import UIKit

class AllAssetHeaderView : NormalHeaderView {
    
    
}
